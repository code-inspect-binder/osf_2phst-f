#' Subset PROSPER-style names
#'
#' A function that takes a vector of PROSPER-style names, SC#C#W#Sch###, and
#' returns the subset corresponding to the state, cohort, wave, and schools
#' specified.
#'
#' @param name: a character vector in the form SC#C#W#Sch###
#' @param state: a vector containing 1 or 2 corresponding to whether we want to
#' select schools from Iowa or Pennsylvania
#' @param wave: a vector containing 1, 2, 3, 4, or 5 corresponding to which
#' waves to keep
#' @param cohort: a vector containing 1 or 2 corresponding to the cohort to be
#' kept.
#' @param school: a vector containing 101, 102, etc. corresponding to the
#' schools to be kept.
#'
#' @return A character vector that is a subset of name corresponding to the
#' state, cohort, wave, and schools specified.
#'
subsetPROSPERNames <- function(name, state = NULL, wave = NULL, cohort = NULL,
                               school = NULL) {
  if (!all(checkPROSPERName(name)))
    stop("Invalid cases in name argument.  Must be a vector of the form SC#C#W#Sch###.")

  if (all(sapply(list(state, wave, cohort, school), is.null)))
    stop("No subsetting requested.")

  # State subsetting
  if (!is.null(state)) {
    # Stop if invalid
    if (!all(state %in% c(1, 2)))
      stop("Invalid state  Must be 1 or 2.")

    # Otherwise, perform subsetting and save output
    list.state <- getState(name)
    name <- name[which(list.state %in% state)]
  }

  # Wave subsetting
  if (!is.null(wave)) {
    if (!all(wave %in% 1:8))
      stop("Invalid wave.  Must be 1, 2, 3, 4, 5, 6, 7, or 8.")
    list.wave <- getWave(name)
    name <- name[which(list.wave %in% wave)]
  }

  # Cohort subsetting
  if (!is.null(cohort)) {
    if (!all(cohort %in% c(1, 2)))
      stop("Invalid cohort.  Must be 1 or 2.")
    list.cohort <- getCohort(name)
    name <- name[which(list.cohort %in% cohort)]
  }

  # School subsetting
  if (!is.null(school)) {
    valid.schools <- c(201L, 301L, 101L, 202L, 302L, 308L, 203L, 303L, 312L, 204L,
                       304L, 222L, 216L, 305L, 307L, 311L, 205L, 110L, 109L, 102L, 106L,
                       105L, 103L, 104L, 108L, 206L, 218L, 306L, 313L, 314L, 215L, 223L,
                       112L, 309L, 219L, 115L, 209L, 117L, 118L, 220L, 210L, 121L, 211L,
                       310L, 123L, 124L, 122L, 212L, 214L, 221L, 150L, 266L, 350L, 258L,
                       355L, 252L, 261L, 360L, 151L, 259L, 351L, 253L, 356L, 354L, 260L,
                       361L, 357L, 255L, 352L, 262L, 353L, 156L, 256L, 158L, 157L, 263L,
                       358L, 257L, 359L, 264L, 265L, 159L, 160L, 161L, 162L)
    if(!all(school %in% valid.schools))
      stop(paste("Invalid school.  Must match one of ", paste(valid.schools,
                                                              collapse = ", "),
                 ".", sep = ""))
    list.school <- getSchool(name)
    name <- name[which(list.school %in% school)]
  }
  return(name)
}
