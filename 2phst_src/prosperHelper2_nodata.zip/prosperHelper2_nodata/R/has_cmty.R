#' Tests whether there is a network attributed named cmty
#'
#' @param net: a statnet network object
#'
#' @return logical value
has.cmty <- function(net) {
  require(network)
  if (!is.network(net))
    stop("Error in has.cmty: net must be a network object")
  return("cmty" %in% list.network.attributes(net))
}
