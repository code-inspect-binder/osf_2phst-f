getSchoolsByWave <- function(PROSPER.names = names(PROSPER.networks), wave) {
  # Gets the unique values of "school" within a given set of waves
  #
  # Args:
  #   PROSPER.names: A character vector of names conforming to the PROSPER
  #                  naming convention, SC#C#W#Sch###
  #   wave: a numeric vector of which waves to keep (allowed values: 1:5)
  #
  # Returns:
  #   A character vector containing the IDs for the schools that were present in
  #   the waves given.
  if (!all(checkPROSPERName(PROSPER.names)))
    stop("PROSPER.names contains a value that doesn't match the PROSPER naming convention.")
  if (!all(wave %in% 1:5))
    stop("Invalid wave.  Must be 1, 2, 3, 4, or 5.")
  match.wave <- which(getWave(PROSPER.names) %in% wave)
  return(getSchool(PROSPER.names[match.wave]))
}