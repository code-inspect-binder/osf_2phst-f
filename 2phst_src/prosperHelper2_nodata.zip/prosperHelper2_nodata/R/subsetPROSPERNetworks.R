#' Subsets the list of PROSPER networks according to the conditions given
#'
#' A wrapper function for \code{subsetPROSPERNames} function applied to the
#' \code{PROSPER.networks} data file.  Updated to subset by cmty too.
#'
#' @param state: a numeric vector of states to keep (1 and/or 2)
#' @param wave: a numeric vector of waves to keep (1 - 5)
#' @param cohort: a numeric vector of cohorts to keep (1 and/or 2)
#' @param school: a numeric vector of schools to keep (101, 102, etc.)
#' @param cmty: a numeric vector of communities to keep (112, )
#' @param data: the \code{PROSPER.networks} data contained with this package
#'
#' @return A named list containing a subset of the PROSPER school networks, or,
#' if there's only one element, just return the network.

subsetPROSPERNetworks <- function(state = NULL, wave = NULL, cohort = NULL,
                                  school = NULL, cmty = NULL,
                                  data = PROSPER.networks) {
  require(statnet)

  if (!is.list(data) || !(sapply(data, class) == "network"))
    stop("data must be a list of networks.")

  if (!all(checkPROSPERName(names(PROSPER.networks))))
    stop("Not all of the names in the data= argument of subsetPROSPERNetworks fit the PROSPER naming convention.")

  # require(digest)
  if(digest::digest(data) != "36ccabdfe6de00c5cdbeb8115ab738b3")
    warning("The data you are using do not match the PROSPER.networks data.  The function may produce inaccurate results")

  # If these are all NULL, subsetPROSPERNames throws an error
  if (!all(sapply(list(state, wave, cohort, school), is.null))) {
    keep <- subsetPROSPERNames(name = names(data), state = state, wave = wave,
                               cohort = cohort, school = school)
    out <- data[which(names(data) %in% keep)]
  } else {
    # TODO(jcf26@): figure out a better way to do this...
    out <- data
  }

  # Subset by cmty, if necessary
  if (!is.null(cmty)) {

    # Validity checks on the cmty value
    if (!is.numeric(cmty))
      stop("cmty must be a numeric vector")

    if (!all(cmty %in% c(112, 115, 116, 121, 123, 111, 114, 122, 124, 125, 126,
                         127, 118, 113, 212, 222, 211, 213, 215, 218, 221, 223,
                         225, 226, 227, 224, 217)))
      stop("Invalid value for cmty")

    if (!all(vapply(out, has.cmty, FUN.VALUE = T, USE.NAMES = F)))
      stop("Not all network objects have a cmty network attribute.")

    # pull the list of communities in the remaining object
    out.cmty <- vapply(out, get.network.attribute, "cmty", FUN.VALUE = 1,
                       USE.NAMES = F)

    out <- out[which(out.cmty %in% cmty)]
  }

  # Just return the network if there's only one match
  if (length(out) == 1)
    out <- out[[1]]

  return(out)
}
