#' A function to get a variable in for the people in a given PROSPER network
#'
#' A fast (data.table) version of getPROSPERVariableByNetwork.  Ideally the two
#' functions will be integrated someday.
#'
#' Takes the ID values in an appropriately named network file and matches them
#' to the main PROSPER survey, and returns a vector of the variable requested
#' from the main survey.
#'
#' @param network: a network objects whose title matches a PROSPER name
#' @param variable: a variable that exists on the survey file
#' @param survey: the file to look up the variable and the ID values.  Defaults
#' to the PROSPER.survey from the prosperHelper package
#'
#' @return A vector of values of variable that corresponds to the people in the
#' network
getPROSPERVariableByNetwork.dt <- function(network, variable, survey) {
  require(data.table)
  require(statnet)
  if (class(network) != "network")
    stop("Invalid argument: network must be a statnet network object.")

  network.name <- get.network.attribute(network, "title")
  if (!checkPROSPERName(network.name))
    stop("Invalid network: network title attribute must follow the PROSPER naming convention.")

  if (!is.data.table(survey))
    stop("getPROSPERVariableByNetwork.dt requires a data.table argument.")
  if (!all(variable %in% names(survey)))
    stop("Invalid argument: variable must be included in the names of survey")
  if (any(key(survey) != c("id","cohort", "wave")))
    stop("Invalid argument: survey must have id, cohort, and wave as key variables.")

  # Get the ID, cohort, and wave values for the current network
  # Recast as integers to address merge problems
  ids <- as.integer(network.vertex.names(network))
  w <- as.integer(getWave(network.name))
  c <- as.integer(getCohort(network.name))

  # Return the variable
  return(survey[J(ids, c, w), variable, with = F])
}
