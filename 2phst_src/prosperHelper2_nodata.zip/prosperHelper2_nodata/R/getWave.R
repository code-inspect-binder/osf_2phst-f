getWave <- function(name) {
  # Function to extract the value for wave from a PROSPER-like string
  #
  # Args:
  #   name: a character string of the form SC#C#W#Sch###
  #
  # Returns:
  #   A numeric value 1, 2, 3, 4, or 5 corresponding to the wave
  if (!all(grepl("SC\\dC\\dW\\dSch\\d+", name)))
    stop("Invalid string.  Must be of form a character string of the form SC#C#W#Sch###.")
  return(substr(name, 7, 7))  
}
