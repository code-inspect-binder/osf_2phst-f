#' Function that adds a vertex attribute to the PROSPER school networks
#' WARNING: No validity checks on the network.  Use with caution!
#'
#' @param network: a networks from the PROSPER survey
#' @param attribute: a string vector representing the variable you want to add
#' @param attr.names: a string vector representing the names of the variables in the
#'               ultimate network file.
#' @param data: the PROSPER survey that you're adding a variable from
#'
#' @return A named list of networks updated to include the variable as a vertex
#'   attribute.
addPROSPERVertexAttribute <- function(network, attribute, attr.name = attribute,
                                      data = PROSPER.survey) {
  require(data.table)
  if (is.data.table(data))
    addPROSPERVertexAttribute.dt(network, attribute, attr.name, data)
  else {
    require(statnet)

    if (class(network) != "network")
      stop("network argument must be a statnet network object.")

    network.title %n% "title"  # save "title" with a more intuitive name
    if (!checkPROSPERName(network.title))
      stop("Network is probably not a PROSPER network (title doesn't match format).")

    if (!all(attribute %in% names(PROSPER.survey)))
      stop("attribute argument must be a variable name in the PROSPER.survey data.")

    if (length(attribute) != length(attr.name))
      stop("Different number of attributes and attribute names.")

    # Get a list of the people in the network
    # Recast as integers to get rid of merge errors.
    people <- as.integer(network.vertex.names(network))

    # Drop cases in the main data that aren't in the right cohort or wave
    # Simultaneously drop variables that you're not going to use.
    small.data <- subset(
        data[, c("id", "cohort", "wave", attribute)],
        (cohort == getCohort(network.title) & wave == getWave(network.title))
        )

    # Get a mapping
    map <- match(people, small.data$id)

    # Attach values to the network object
    set.vertex.attribute(network, attr.name, small.data[map, attribute])

    return(network)
  }
}
