checkPROSPERName <- function(name) {
  # A function to check if a name conforms to the PROSPER naming convention
  #
  # Args:
  #   name: a character vector
  #
  # Returns:
  #   TRUE or FALSE, depending on whether the name matches SC#C#W#Sch###
  if (!is.character(name))
    stop("checkPROSPER requires a character vector.")
  return(grepl("^SC\\dC\\dW\\dSch\\d{3}$", name))
}
