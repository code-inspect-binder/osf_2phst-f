## ---- echo = T-----------------------------------------------------------
library(prosperHelper2)
data("PROSPER.survey")
tables()

## ---- echo = T-----------------------------------------------------------
library(prosperHelper2)
data(PROSPER.networks)
first.network <- subsetPROSPERNetworks(school = 101, wave = 1, cohort = 1)
(network.name <- first.network %n% "title")
checkPROSPERName(network.name)
getSchool(network.name)

## ---- echo = T-----------------------------------------------------------
library(prosperHelper2)
library(data.table)
data(PROSPER.networks)
data(PROSPER.survey)
first.network <- PROSPER.networks[[1]]
getPROSPERVariableByNetwork(first.network, "tsex_rfinal")
new.network <- addPROSPERVertexAttribute(first.network, "tsex_rfinal", "sex")
new.network %v% "sex"

