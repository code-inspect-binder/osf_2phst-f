#' Fast (data.table) version of addPROSPERVertexAttribute
#'
#' @param network: a statnet network object with a PROSPER title
#' @param attribute: a string vector with the names of the variables to be added
#' @param attr.name: an optional string variable with the names of the variables
#' on the returned network object
#' @param data: a data.table with the PROSPER survey
#'
#' @return the network with the variables given as vertex attributes
addPROSPERVertexAttribute.dt <- function(network, attribute,
                                         attr.name = attribute,
                                         data = PROSPER.survey) {
  require(statnet)
  require(data.table)

  if (class(network) != "network")
    stop("addPROSPERVertexAttribute.dt requires a network argument.")
  if (!is.data.table(data))
    stop("addPROSPERVertexAttribute.dt requires a data.table.")
  if (length(attribute) != length(attr.name))
    stop("Number of attributes and attribute names doesn't match.")

  var <- getPROSPERVariableByNetwork.dt(network, attribute, data)

  # set.vertex.attribute doesn't work with a data.table with 1 variable so if
  # that's the case, unlist the results
  if (length(var) == 1)
    var <- unlist(var)

  set.vertex.attribute(network, attrname = attr.name, value = var)

  return(network)
}
