# # Author: Jake Fisher
# # Save the network and data files for prosperHelper2
#
# # Set up workspace
# rm(list = ls())
# setwd("C:/Users/fishe/Box Sync/Home Folder jcf26/PROSPER")
# library(prosperHelper2)
# library(statnet)
# library(data.table)
# library(dplyr)
#
# readAllPajekFiles <- function(folder) {
#   # Function to read all the .net files into a single list of network objects
#   #
#   # Args:
#   #   folder: a path containing at least 1 .net file
#   #
#   # WARNING: dat is not checked for validity.  Use with caution.
#   #
#   # Returns:
#   #   A list whose items are the Pajek .net files in the folder, named using the
#   #   PROSPER naming convention
#   require(tools)
#   require(statnet)
#
#   # Save the old working directory and move to folder
#   old.wd <- getwd()
#   setwd(folder)
#
#   # Subset out the files with ".net" extension
#   files <- list_files_with_exts(".", "net", full.names = FALSE)
#   net.names <- file_path_sans_ext(files)
#
#   # Make sure (a) there are files, and (b) they all have PROSPER-style names
#   stopifnot(length(files) > 0)
#   stopifnot(all(sapply(net.names, checkPROSPERName)))
#
#   # Read in all the networks, and make sure they are named appropriately
#   networks <- lapply(files, read.paj)
#   names(networks) <- net.names
#
#   # Return the network object and reset the working directory
#   return(networks)
#   setwd(old.wd)
# }
#
# saveCommunity <- function(net, dat = communities) {
#   # Adds community as a network attribute to the network objects in net
#   #
#   # Args:
#   #   net: a network object with a PROSPER name
#   #   dat: a data.table with cohort, wave, school, and cmty variables
#   #
#   # WARNING: few validity checks on data, use with caution
#   #
#   # Returns:
#   #   The same network object, with a new network attribute, cmty
#   require(statnet)
#   title <- net %n% "title"
#   ch <- as.numeric(getCohort(title))
#   wv <- as.numeric(getWave(title))
#   sch <- as.numeric(getSchool(title))
#
#   cmty <- dat[J(ch, wv, sch)]$cmty
#   net %n% "cmty" <- cmty
#   return(net)
# }
#
# saveNetAttrs <- function(net) {
#   # Saves the state, cohort, wave, and community values for each network
#   #
#   # Args:
#   #   net: a statnet network with a PROSPER-style name and a cmty network
#   #        attribute
#   #
#   # Returns:
#   #   A data.frame with variables for state, cohort, wave, and community values
#   title <- net %n% "title"
#   ch <- as.numeric(getCohort(title))
#   wv <- as.numeric(getWave(title))
#   sch <- as.numeric(getSchool(title))
#
#   return(data.frame(cohort = ch, wave = wv, school = sch,
#                     cmty = as.numeric(net %n% "cmty")))
# }
#
#
# # Load raw PROSPER data
# system.time(load("ind_maindata_5_1_15.Rdata"))
#
# # Convert to data.table for speed
# PROSPER.survey <- data.table(ind_maindata_5_1_15, key = c("id", "cohort",
#                                                           "wave"))
#
# # Save data file for package
# save(PROSPER.survey, file = "H:/R_libraries/prosperHelper2/data/PROSPER.survey.rda")
#
# # Create a school/cohort/wave level file with community values
# communities <- group_by(PROSPER.survey, cohort, wave, school) %>%
#   summarize(cmty = unique(cmty)) %>%
#   setkeyv(., c("cohort", "wave", "school"))
#
# # Load PROSPER networks
# nets <- readAllPajekFiles(".")
# PROSPER.networks <- lapply(nets, saveCommunity)
#
# save(PROSPER.networks, file = "C:/Users/fishe/Documents/duke-soc-server/R_libraries/prosperHelper2/data/PROSPER.networks.rda")
#
# # Testing
# test <- do.call(rbind, lapply(PROSPER.networks, saveNetAttrs)) %>%
#   dplyr::mutate_each(funs(as.integer)) %>%
#   mutate(one = 1)  # indicator of "in network data"
#
# both <- full_join(test, communities)
