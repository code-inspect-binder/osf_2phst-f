# Author: Jake Fisher
# Save updated survey file for prosperHelper as a data.table
#
# # Set up workspace
# rm(list = ls())
# # # setwd("H:/Datasets/PROSPER")
# # # Updated with new location, 14 Oct. 2015
# setwd("C:/Users/fishe/Box Sync/Home Folder jcf26/PROSPER")
# library(data.table)

# # Load data
# load("~/lanhome/Datasets/PROSPER/ind_maindata_5_1_12.Rdata")
# load("indlevc.Rdata")
# load("netlevc.Rdata")
#
# Set the library back to where you want the data saved
# setwd("H:/R_libraries/prosperHelper/data")
#
# # Make data.table
# PROSPER.survey <- data.table(ind_maindata_5_1_12, key = c("id", "cohort",
#                                                           "wave"))
#
# PROSPER.individual.netvars <- data.table(indlevc, key = c("id", "cohort",
#                                                           "wave"))
#
# PROSPER.netvars <- data.table(netlevc, key = c("school", "cohort", "wave"))
#
# # Save the output
# save(PROSPER.survey, file = "PROSPER.survey.rda")

# Updated 14 Oct. 2015
# load("ind_maindata_w216_10_7_15.rdata")
#
# PROSPER.survey <- data.table(ind_maindata_w216_10_7_15,
#                              key = c("id", "cohort", "wave"))
#
# save(PROSPER.survey,
#      file = "H:/R_libraries/prosperHelper2/data/PROSPER.survey.rda")

# Updated 28 Oct. 2015
# load("indlevcombined.Rdata")
# PROSPER.individual.netvars <- data.table(indlevcombined,
#                                          key = c("id", "cohort", "wave"))
# save(PROSPER.individual.netvars, file = "PROSPER.individual.netvars.rda")
# rm(indlevcombined, PROSPER.individual.netvars)
#
# load("netevcombined.Rdata")
# PROSPER.netvars <- data.table(netevcombined,
#                               key = c("school", "cohort", "wave"))
# save(PROSPER.netvars, file = "PROSPER.netvars.rda")
#
#
# # Updated 16 Aug. 2016
# # Add the group data
# load("group_indlev.Rdata")
# PROSPER.groups <- data.table(group_indlev, key = c("id", "cohort", "wave"))
# save(PROSPER.groups, file = "C:/Users/fishe/Documents/duke-soc-server/R_libraries/prosperHelper2/data/PROSPER.groups.rda")
#
#
# # Group-level indicators aren't terribly comparable between waves 1-5 and 6-8
# # Waves 6-8 they're in 1 file:
# load("group_grplev.Rdata")
#
# # Waves 1-5 they're separated into two -- one for demographics, one for network
# # stuff
# load("jig_totgrpchars1.Rdata")
# load("peergrpdemogs.Rdata")
# peergrpdemogs$grpsize <- NULL
#
# # So, first, let's merge the wave 1-5 files:
# w15 <- merge(x = jig_totgrpchars1, y = peergrpdemogs, all = T,
#              by = c("group", "cohort", "school", "wave"))
#
# # Next let's rbind them to the wave 6-8 file
# PROSPER.group.vars <- rbindlist(list(w15, group_grplev), fill = T)
# setkey(PROSPER.group.vars, group, school, cohort, wave)
#
# # Finally, save them to a file
# save(PROSPER.group.vars, file = "C:/Users/fishe/Documents/duke-soc-server/R_libraries/prosperHelper2/data/PROSPER.group.vars.rda")
