#' A function to merge the group IDs onto the main PROSPER data
#'
#'
#' @param dat: the main PROSPER data (data(PROSPER.survey))
#' @param groups.dat: the dataset with the PROSPER group IDs
#' (data(PROSPER.groups))
#' 
#' @return A data.table of the main PROSPER survey with one additional variable,
#' group, corresponding to the group ID value from the PROSPER 
getPROSPERGroups <- function(dat = PROSPER.survey, groups.dat = PROSPER.groups) {
  if (!is.data.table(dat) || !(all(c("id", "cohort", "wave") %in% names(dat))))
    stop("dat must be a data table with id, cohort, and wave columns.")
  if (!is.data.table(groups.dat) || !(all(c("id", "cohort", "wave") %in% 
                                            names(dat))))
    stop("groups.dat must be a data.table with id, cohort, and wave columns")
  
  # Subset the groups data
  groups <- groups.dat[, .(id, cohort, wave, group)]
  
  if (any(key(dat) != key(groups)))
    stop("groups.dat and dat must have the same key columns")
  
  return(merge(dat, groups, all.x = T, all.y = F))
}