#' A function to get a variable in for the people in a given PROSPER network
#' 
#' Takes the ID values in an appropriately named network file and matches them 
#' to the main PROSPER survey, and returns a vector of the variable requested
#' from the main survey
#' 
#' @param network: a network objects whose title matches a PROSPER name
#' @param variable: a variable that exists on the survey file
#' @param survey: the file to look up the variable and the ID values.  Defaults
#' to the PROSPER.survey from the prosperHelper package
#' 
#' @return A vector of values of variable that corresponds to the people in the
#' network
getPROSPERVariableByNetwork <- function(network, variable, 
                                        survey = PROSPER.survey) {
  require(data.table)
  if (any(class(survey) == "data.table"))
    getPROSPERVariableByNetwork.dt(network, variable, survey)
  else {
    require(statnet)
    if (class(network) != "network")
      stop("Invalid argument: network must be a statnet network object.")
    
    network.name <- get.network.attribute(network, "title")
    if (!checkPROSPERName(network.name))
      stop("Invalid network: network title attribute must follow the PROSPER naming convention.")
    
    if (!(variable %in% names(survey)))
      stop("Invalid argument: variable must be included in the names of survey")
    if (!all(c("id","cohort", "wave") %in% names(survey)))
      stop("Invalid argument: survey must contain the variables id, cohort, and wave.")  
    
    # Drop everything other than the correct wave and cohort
    current.wave <- getWave(network.name)
    current.cohort <- getCohort(network.name)
    wave.and.cohort <- subset(survey, (cohort == current.cohort & 
                                         wave == current.wave))
    if (nrow(wave.and.cohort) == 0)
      stop("No ID values found for the given wave and cohort.")
    
    # Get a mapping of where the ID values are in the 
    ids <- network.vertex.names(network)
    map <- match(ids, wave.and.cohort$id)
    
    # Warn if you couldn't find all the values
    if (sum(is.na(map)) > 0)
      warning("Not all of the IDs could be found in the main data.  This may indicate an invalid input.")
    
    # Return the variable
    return(wave.and.cohort[map, variable])  
  }
}