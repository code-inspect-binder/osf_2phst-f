---
title: "A quick overview to prosperHelper2"
author: "Jake Fisher"
date: "2015-08-14"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{prosperHelper2}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---

The prosperHelper2 package contains the PROSPER data, and functions to facilitate its use.  prosperHelper2 updates prosperHelper to include data from waves 6 - 8.  This vignette describes the data and functions included in the package.

**WARNING**: Not all of the functions in this package perform checks on the inputs.  In some cases, it will be possible for you to use the functions on incorrect datasets, and get unexpected or inaccurate results.  Use with caution.

# Data

The prosperHelper package contains 7 datasets:

1. `PROSPER.survey`: a data.table that contains the main survey questions in an individual-level dataset
2. `PROSPER.networks`: a list of statnet network objects, where each list element is a network from a different school setting, meaning a different unique school, cohort, and wave combination.
3. `PROSPER.netvars`: a school setting-level data.table of variables calculated for each network (e.g., density, homophily)
4. `PROSPER.individual.netvars`: an individual-level data.table of network variables about each individual (e.g., in-degree, out-degree)
5. `PROSPER.groups`: an individual-level data.table of group characteristics
for each person, including group assignments (where groups are from the CROWDS alogrithm)
6. `PROSPER.romantic.vars`: an individual-level data.table with characteristics of each person's romantic partner
7. `PROSPER.group.vars`: a group-level data.table with characteristics of each group (e.g., number of ties to people outside of the group, group size, etc.)

Most of the documentation for these datasets can be found in the codebooks, and in the descriptions of the SAS variables (i.e., load the original SAS datasets in SAS, and run PROC CONTENTS).

Each dataset can be loaded with the `data` command, e.g., `data(PROSPER.survey)` will load a data.table object called PROSPER.survey in the global environment.

## Keys

The datasets are saved as `data.table` objects.  `data.table` is an R package that allows speedy manipulation of large datasets.  Although the PROSPER data are not very large -- the data will fit in memory on a modern laptop -- using the `data.table` speeds up some of the operations.

`data.table` makes things faster by "keying" the data, meaning it sorts the data by several variables, and then uses those variables to look up rows in the data quickly.  The data saved here are keyed by the variables `id`, `cohort`, and `wave` for individual-level data (datasets 1, 4, 5, and 6), by the variables `school`, `cohort`, and `wave` for the school setting-level data (dataset 3), and by the variables `group`, `school`, `cohort`, and `wave` for the group-level data (dataset 7).  To find these quickly, run the command `tables()` after loading a dataset.  For example:


```r
library(prosperHelper2)
data("PROSPER.survey")
tables()
```

```
##      NAME             NROW NCOL  MB
## [1,] PROSPER.survey 91,852  339 128
##      COLS                                                                            
## [1,] id,cohort,wave,state,cmty,school,cmtycoh,cond_treat,cond_rand,keepers,coutcom,in
##      KEY           
## [1,] id,cohort,wave
## Total: 128MB
```

# Functions

The functions included in this function largely fall into two categories.  First, many of the functions are wrappers for a regular expression that parses the standard PROSPER school-cohort-wave code, SC#C#W#Sch###.  Second, the remaining functions join the survey data to the network files.

## Regular expression wrappers

The standard PROSPER naming convention is SC#C#W#Sch###.  For example, take school 212, state 1, cohort 2, wave 4.  The naming convention would be written SC1C2W4Sch212.  Note that the state is not necessary to uniquely describe a school setting -- once you know the school number, you could, in principle, figure out the state.

The PROSPER naming convention is primarily used in the list names for the `PROSPER.networks` list, and the titles for the networks in `PROSPER.networks`.  The functions are as follows:

* checkPROSPERName
* getSchool
* getCohort
* getState
* getWave

There are also two wrappers for these that subset the network file to get specific networks, `subsetPROSPERNames` and `subsetPROSPERNetworks`.  Full documentation *should* be in the function documentation.  Here's an example of how these are used.


```r
library(prosperHelper2)
data(PROSPER.networks)
first.network <- subsetPROSPERNetworks(school = 101, wave = 1, cohort = 1)
```

```
## Loading required package: digest
```

```r
(network.name <- first.network %n% "title")
```

```
## [1] "SC1C1W1Sch101"
```

```r
checkPROSPERName(network.name)
```

```
## [1] TRUE
```

```r
getSchool(network.name)
```

```
## [1] "101"
```

## Joining the survey data to the network file

There are two functions to join survey data to the network file.  The `getPROSPERVariableByNetwork` function returns a data.frame with the values of a survey variable corresponding to the people in a network, and the `addPROSPERVertexAttribute` function returns a network with a PROSPER variable as a vertex attribute.

Both of these functions are *slow* (5 - 10 seconds per network).  To speed them up, I rewrote them using the `data.table` package.  The faster, rewritten functions are `getPROSPERVariableByNetwork.dt` and `addPROSPERVertexAttribute.dt`.  Ideally, calling the original functions and specifying a `data.table` as the `data` argument will automatically call the `data.table` version.

For an example, here's how the functions can be used:


```r
library(prosperHelper2)
library(data.table)
data(PROSPER.networks)
data(PROSPER.survey)
first.network <- PROSPER.networks[[1]]
getPROSPERVariableByNetwork(first.network, "tsex_rfinal")
```

```
##      tsex_rfinal
##   1:           1
##   2:           0
##   3:           1
##   4:           1
##   5:           1
##  ---            
## 110:           0
## 111:           0
## 112:           0
## 113:           1
## 114:           1
```

```r
new.network <- addPROSPERVertexAttribute(first.network, "tsex_rfinal", "sex")
new.network %v% "sex"
```

```
##   [1]  1  0  1  1  1  1  0  0  1  1  0  1  1  1  0  1  0  0  1  0  1 NA  0
##  [24] NA  0 NA  1 NA  1  0  0  1  1  0  0  0  1  0  0  0  0  0  0  0  1  1
##  [47]  1  0  1  1  1  0  1  1  0  1  0  1  0  1  1 NA  1 NA  0  1  1  1  0
##  [70]  0  1  0  0  1  0  0  0  0  1  0  0  0  1  0 NA  1  1  1  1  0  1  1
##  [93]  1  0  1  0  1  0  1  1  1  0  1  0  1  1  1  1  0  0  0  0  1  1
```

You can pass vectors to the attribute argument to get more than one variable at a time, e.g., instead of `"tsex_rfinal"`, `c("tsex_rfinal", "cslun_r")`.  You can use this with lapply to loop through all of the networks.



# Miscelleny

There's also two recoding functions in there, `recodeState` and `recodeGender`.  I created those so that I wouldn't have to look up whether 1 or 0 was male or female  (1 is female).

New function!  `getPROSPERGroups` takes the PROSPER survey and merges the group variable from `PROSPER.groups` onto it.
